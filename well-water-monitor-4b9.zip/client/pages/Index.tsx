import { useState, useEffect } from "react";
import {
  Droplet,
  Battery,
  Signal,
  TrendingUp,
  MapPin,
  Clock,
  Zap,
  Edit2,
} from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

const AIO_USERNAME = "OptimonSKG";
const AIO_KEY = "aio_RZgR94Kft3b2hFxyQcIh4CA3uDaS";

interface AdafruitDataPoint {
  value: number;
  created_at: string;
}

export default function Index() {
  const [lastUpdated, setLastUpdated] = useState<string>("");
  const [waterLevel, setWaterLevel] = useState<number>(0);
  const [batteryLevel, setBatteryLevel] = useState<number>(0);
  const [sensorCurrent, setSensorCurrent] = useState<number>(0);
  const [chartData, setChartData] = useState<Array<{ time: string; depth: number }>>([]);
  const [systemStatus, setSystemStatus] = useState<"online" | "offline">("online");
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Volume calculator state
  const [wellRadius, setWellRadius] = useState<number>(0.6);
  const [totalWellDepth, setTotalWellDepth] = useState<number>(10);
  const [isEditingRadius, setIsEditingRadius] = useState<boolean>(false);
  const [isEditingDepth, setIsEditingDepth] = useState<boolean>(false);

  const calculateWaterVolume = (): number => {
    return Math.PI * Math.pow(wellRadius, 2) * (totalWellDepth - waterLevel) * 1000;
  };

  const fetchAdafruitData = async () => {
    try {
      setLoading(true);
      setError(null);

      // Fetch battery level
      const batteryRes = await fetch(
        `https://io.adafruit.com/api/v2/${AIO_USERNAME}/feeds/battery/data/last`,
        { headers: { "X-AIO-Key": AIO_KEY } }
      );
      if (batteryRes.ok) {
        const batteryData = (await batteryRes.json()) as AdafruitDataPoint;
        setBatteryLevel(Number(batteryData.value));
      }

      // Fetch sensor current
      const sensorRes = await fetch(
        `https://io.adafruit.com/api/v2/${AIO_USERNAME}/feeds/sensor-ma-measurement/data/last`,
        { headers: { "X-AIO-Key": AIO_KEY } }
      );
      if (sensorRes.ok) {
        const sensorData = (await sensorRes.json()) as AdafruitDataPoint;
        setSensorCurrent(Number(sensorData.value));
      }

      // Fetch depth history for chart
      const depthRes = await fetch(
        `https://io.adafruit.com/api/v2/${AIO_USERNAME}/feeds/depth/data?limit=100`,
        { headers: { "X-AIO-Key": AIO_KEY } }
      );
      if (depthRes.ok) {
        const depthDataRaw = (await depthRes.json()) as AdafruitDataPoint[];
        if (depthDataRaw.length > 0) {
          // Get current depth from first (most recent) entry
          setWaterLevel(Number(depthDataRaw[0].value));

          // Process data for chart (reverse to show chronological order)
          const processedData = depthDataRaw
            .reverse()
            .map((point) => ({
              time: new Date(point.created_at).toLocaleTimeString("en-US", {
                hour: "2-digit",
                minute: "2-digit",
              }),
              depth: Number(point.value),
            }))
            .slice(0, 50); // Limit to last 50 entries

          setChartData(processedData);
        }
      }

      setSystemStatus("online");
      setLastUpdated(new Date().toLocaleString());
    } catch (err) {
      console.error("Error fetching Adafruit IO data:", err);
      setError("Failed to fetch data from Adafruit IO");
      setSystemStatus("offline");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAdafruitData();
    // Refresh data every 30 seconds
    const interval = setInterval(fetchAdafruitData, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground dark">
      {/* Header */}
      <header className="bg-card border-b border-border sticky top-0 z-10 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-gradient-to-br from-primary to-secondary rounded-lg">
                <Droplet className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-foreground">
                  Well Water Level Monitor
                </h1>
                <p className="text-muted-foreground text-sm mt-1">
                  Real-time IoT Telemetry Dashboard • Connected to Adafruit IO
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 bg-muted rounded-lg px-4 py-2 text-sm">
              <Clock className="w-4 h-4 text-accent" />
              <div>
                <p className="text-muted-foreground text-xs uppercase tracking-wide">
                  Last Updated
                </p>
                <p className="font-mono text-foreground">
                  {lastUpdated || "Loading..."}
                </p>
              </div>
            </div>
          </div>
          {error && (
            <div className="mt-4 bg-red-500/10 border border-red-500/20 rounded-lg p-3">
              <p className="text-red-400 text-sm">{error}</p>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Grid */}
        <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {/* Current Depth Card */}
          <div className="bg-card rounded-lg border border-border p-6 hover:border-accent transition-colors">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-muted-foreground text-sm font-medium uppercase tracking-wide">
                  Water Depth
                </p>
                <p className="text-4xl font-bold text-primary mt-2">
                  {loading ? "..." : waterLevel.toFixed(2)}
                  <span className="text-lg text-muted-foreground ml-2">m</span>
                </p>
                <p className="text-xs text-muted-foreground mt-2">
                  Below ground surface
                </p>
              </div>
              <div className="p-3 bg-primary/10 rounded-lg">
                <Droplet className="w-8 h-8 text-primary" />
              </div>
            </div>
            <div className="mt-4 h-1 bg-muted rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-primary to-secondary transition-all duration-500"
                style={{ width: `${Math.min((waterLevel / totalWellDepth) * 100, 100)}%` }}
              ></div>
            </div>
          </div>

          {/* Battery Level Card */}
          <div className="bg-card rounded-lg border border-border p-6 hover:border-accent transition-colors">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-muted-foreground text-sm font-medium uppercase tracking-wide">
                  Battery Level
                </p>
                <p className="text-4xl font-bold text-accent mt-2">
                  {loading ? "..." : batteryLevel.toFixed(1)}
                  <span className="text-lg text-muted-foreground ml-2">%</span>
                </p>
                <p className="text-xs text-muted-foreground mt-2">
                  Adafruit IO Feed
                </p>
              </div>
              <div className="p-3 bg-accent/10 rounded-lg">
                <Battery className="w-8 h-8 text-accent" />
              </div>
            </div>
            <div className="mt-4 h-1 bg-muted rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-accent to-secondary transition-all duration-500"
                style={{ width: `${Math.min(batteryLevel, 100)}%` }}
              ></div>
            </div>
          </div>

          {/* Sensor Current Card */}
          <div className="bg-card rounded-lg border border-border p-6 hover:border-accent transition-colors">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-muted-foreground text-sm font-medium uppercase tracking-wide">
                  Sensor Current
                </p>
                <p className="text-4xl font-bold text-secondary mt-2">
                  {loading ? "..." : sensorCurrent.toFixed(2)}
                  <span className="text-lg text-muted-foreground ml-2">mA</span>
                </p>
                <p className="text-xs text-muted-foreground mt-2">
                  Current draw
                </p>
              </div>
              <div className="p-3 bg-secondary/10 rounded-lg">
                <Zap className="w-8 h-8 text-secondary" />
              </div>
            </div>
          </div>

          {/* System Status Card */}
          <div className="bg-card rounded-lg border border-border p-6 hover:border-accent transition-colors">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-muted-foreground text-sm font-medium uppercase tracking-wide">
                  System Status
                </p>
                <p className="text-2xl font-bold mt-4 flex items-center gap-2">
                  <span
                    className={`w-3 h-3 rounded-full animate-pulse ${
                      systemStatus === "online"
                        ? "bg-green-500"
                        : "bg-red-500"
                    }`}
                  ></span>
                  <span className="text-foreground capitalize">
                    {systemStatus}
                  </span>
                </p>
                <p className="text-xs text-muted-foreground mt-2">
                  Real-time connectivity
                </p>
              </div>
              <div
                className={`p-3 rounded-lg ${
                  systemStatus === "online"
                    ? "bg-green-500/10"
                    : "bg-red-500/10"
                }`}
              >
                <Signal
                  className={`w-8 h-8 ${
                    systemStatus === "online"
                      ? "text-green-500"
                      : "text-red-500"
                  }`}
                />
              </div>
            </div>
          </div>
        </section>

        {/* Main Visualization Grid */}
        <section className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Line Chart - Takes 2 columns on larger screens */}
          <div className="lg:col-span-2 bg-card rounded-lg border border-border p-6">
            <div className="mb-6">
              <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-primary" />
                Water Depth Trends
              </h2>
              <p className="text-muted-foreground text-sm mt-1">
                Real-time depth measurements from Adafruit IO
              </p>
            </div>
            {loading ? (
              <div className="h-80 flex items-center justify-center text-muted-foreground">
                Loading chart data...
              </div>
            ) : chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#2a4a5a" />
                  <XAxis
                    dataKey="time"
                    stroke="#6b7b8a"
                    style={{ fontSize: "12px" }}
                  />
                  <YAxis stroke="#6b7b8a" style={{ fontSize: "12px" }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#0f1f2f",
                      border: "1px solid #2a4a5a",
                      borderRadius: "8px",
                    }}
                    labelStyle={{ color: "#e0f2ff" }}
                    formatter={(value) => `${value.toFixed(2)}m`}
                  />
                  <Line
                    type="monotone"
                    dataKey="depth"
                    stroke="#0ea5e9"
                    strokeWidth={3}
                    dot={{ fill: "#0ea5e9", r: 4 }}
                    activeDot={{ r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-80 flex items-center justify-center text-muted-foreground">
                No chart data available
              </div>
            )}
          </div>

          {/* Vertical Tank Gauge */}
          <div className="bg-card rounded-lg border border-border p-6 flex flex-col">
            <div className="mb-6">
              <h2 className="text-xl font-bold text-foreground">
                Water Tank Level
              </h2>
              <p className="text-muted-foreground text-sm mt-1">Visual indicator</p>
            </div>
            <div className="flex-1 flex flex-col items-center justify-center gap-6">
              {/* Tank */}
              <div className="relative w-24 h-64">
                <div className="absolute inset-0 border-4 border-primary rounded-2xl bg-muted/30">
                  <div
                    className="absolute bottom-0 w-full bg-gradient-to-t from-accent to-primary rounded-bl-2xl rounded-br-2xl transition-all duration-500"
                    style={{
                      height: `${Math.min((waterLevel / totalWellDepth) * 100, 100)}%`,
                    }}
                  ></div>
                  {/* Wave effect */}
                  <div
                    className="absolute bottom-0 w-full h-1 bg-accent/50 animate-pulse"
                    style={{
                      height: `${Math.min((waterLevel / totalWellDepth) * 100, 100)}%`,
                    }}
                  ></div>
                </div>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-primary">
                  {Math.min((waterLevel / totalWellDepth) * 100, 100).toFixed(1)}%
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Tank Capacity
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Volume Calculator Card */}
        <section className="bg-card rounded-lg border border-border p-6 mb-8">
          <h2 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2">
            <Droplet className="w-5 h-5 text-accent" />
            Water Volume Calculator
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Well Radius Input */}
            <div className="bg-muted/50 rounded-lg p-4 border border-border">
              <div className="flex items-center justify-between mb-3">
                <p className="text-muted-foreground text-sm font-medium uppercase tracking-wide">
                  Well Radius
                </p>
                <button
                  onClick={() => setIsEditingRadius(!isEditingRadius)}
                  className="p-1.5 hover:bg-muted rounded-lg transition-colors"
                >
                  <Edit2 className="w-4 h-4 text-accent" />
                </button>
              </div>
              {isEditingRadius ? (
                <input
                  type="number"
                  value={wellRadius}
                  onChange={(e) => setWellRadius(parseFloat(e.target.value) || 0)}
                  onBlur={() => setIsEditingRadius(false)}
                  className="w-full bg-input border border-border rounded px-3 py-2 text-foreground text-lg font-bold focus:outline-none focus:border-primary"
                  step="0.1"
                  autoFocus
                />
              ) : (
                <p className="text-2xl font-bold text-primary">
                  {wellRadius.toFixed(2)}
                  <span className="text-sm text-muted-foreground ml-2">m</span>
                </p>
              )}
            </div>

            {/* Total Depth Input */}
            <div className="bg-muted/50 rounded-lg p-4 border border-border">
              <div className="flex items-center justify-between mb-3">
                <p className="text-muted-foreground text-sm font-medium uppercase tracking-wide">
                  Total Well Depth
                </p>
                <button
                  onClick={() => setIsEditingDepth(!isEditingDepth)}
                  className="p-1.5 hover:bg-muted rounded-lg transition-colors"
                >
                  <Edit2 className="w-4 h-4 text-accent" />
                </button>
              </div>
              {isEditingDepth ? (
                <input
                  type="number"
                  value={totalWellDepth}
                  onChange={(e) => setTotalWellDepth(parseFloat(e.target.value) || 0)}
                  onBlur={() => setIsEditingDepth(false)}
                  className="w-full bg-input border border-border rounded px-3 py-2 text-foreground text-lg font-bold focus:outline-none focus:border-primary"
                  step="0.1"
                  autoFocus
                />
              ) : (
                <p className="text-2xl font-bold text-primary">
                  {totalWellDepth.toFixed(2)}
                  <span className="text-sm text-muted-foreground ml-2">m</span>
                </p>
              )}
            </div>

            {/* Water Volume Result */}
            <div className="bg-gradient-to-br from-primary/10 to-secondary/10 rounded-lg p-4 border border-primary/20">
              <p className="text-muted-foreground text-sm font-medium uppercase tracking-wide mb-3">
                Water Volume
              </p>
              <p className="text-3xl font-bold text-accent">
                {calculateWaterVolume().toFixed(2)}
                <span className="text-sm text-muted-foreground ml-2">L</span>
              </p>
              <p className="text-xs text-muted-foreground mt-2">
                Formula: π × r² × (Total Depth - Current Depth) × 1000
              </p>
            </div>
          </div>
        </section>

        {/* Map Section */}
        <section className="bg-card rounded-lg border border-border p-6">
          <div className="mb-6">
            <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
              <MapPin className="w-5 h-5 text-primary" />
              Well Location
            </h2>
            <p className="text-muted-foreground text-sm mt-1">
              GPS coordinates: 36.984083° N, 24.704250° E
            </p>
          </div>

          {/* Google Maps */}
          <div className="relative w-full h-96 bg-muted rounded-lg overflow-hidden border border-border">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d378282.27984368906!2d24.474902!3d36.984083!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14a0dd3e3e3e3e3d%3A0x0!2sWell%20Monitoring%20Site!5e0!3m2!1sen!2sgr!4v1234567890"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
            <div className="absolute top-4 right-4 bg-card rounded-lg border border-border px-4 py-2 shadow-lg">
              <p className="text-xs text-muted-foreground uppercase tracking-wide">
                Coordinates
              </p>
              <p className="text-sm font-mono text-primary mt-1">
                36.9841° N, 24.7043° E
              </p>
            </div>
          </div>

          {/* Map Info */}
          <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-muted rounded-lg p-4 border border-border">
              <p className="text-xs text-muted-foreground uppercase tracking-wide">
                Latitude
              </p>
              <p className="text-lg font-mono text-foreground mt-1">36.984083</p>
            </div>
            <div className="bg-muted rounded-lg p-4 border border-border">
              <p className="text-xs text-muted-foreground uppercase tracking-wide">
                Longitude
              </p>
              <p className="text-lg font-mono text-foreground mt-1">24.704250</p>
            </div>
            <div className="bg-muted rounded-lg p-4 border border-border">
              <p className="text-xs text-muted-foreground uppercase tracking-wide">
                Region
              </p>
              <p className="text-lg font-mono text-foreground mt-1">Crete, Greece</p>
            </div>
          </div>
        </section>

        {/* System Info */}
        <section className="mt-8 bg-gradient-to-r from-primary/5 to-secondary/5 rounded-lg border border-border p-6">
          <h3 className="text-lg font-bold text-foreground mb-4 flex items-center gap-2">
            <Signal className="w-5 h-5 text-primary" />
            Connected Feeds
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div className="p-3 bg-card/50 rounded border border-border">
              <p className="text-muted-foreground uppercase text-xs tracking-wide mb-2">
                Battery Feed
              </p>
              <p className="font-mono text-foreground text-xs break-all">
                OptimonSKG/feeds/battery
              </p>
            </div>
            <div className="p-3 bg-card/50 rounded border border-border">
              <p className="text-muted-foreground uppercase text-xs tracking-wide mb-2">
                Sensor Current Feed
              </p>
              <p className="font-mono text-foreground text-xs break-all">
                OptimonSKG/feeds/sensor-ma-measurement
              </p>
            </div>
            <div className="p-3 bg-card/50 rounded border border-border">
              <p className="text-muted-foreground uppercase text-xs tracking-wide mb-2">
                Depth Feed
              </p>
              <p className="font-mono text-foreground text-xs break-all">
                OptimonSKG/feeds/depth
              </p>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
